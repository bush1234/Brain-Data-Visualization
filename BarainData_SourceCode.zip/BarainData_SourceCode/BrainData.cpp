#include <windows.h>

#include <GL/glew.h>

#include <GL/freeglut.h>

#include <GL/gl.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <glm/gtx/string_cast.hpp>

#include <iostream>

#include "InitShader.h"
#include "LoadMesh.h"
#include "LoadTexture.h"
#include "imgui_impl_glut.h"
#include "VideoMux.h"

#include "DebugCallback.h";

//texture
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define NUM_BRAIN_OBJ 116

//names of the shader files to load
static const std::string vertex_shader("BrainData_vs.glsl");
static const std::string fragment_shader("BrainData_fs.glsl");

GLuint shader_program = -1;
//GLuint texture_id = -1; //Texture map for fish
GLuint texture_id; 

//windows distortion
float aspect = 1.0f;

//Lab 1.2 ..... Problem 2
GLint timeLoc; /* Uniform index for variable "time" in shader */
GLfloat timeValue; /* Application time */

GLuint vao = -1;

GLuint quad_vao = -1;
GLuint quad_vbo = -1;

GLuint fbo_id = -1;       // framebuffer object,
GLuint shadow_map_texture_id = -1;

GLuint colorBuffer = -1; //HDR
unsigned int colorBuffers[2];
GLuint hdrFBO = -1;  //// framebuffer object for HDR

int shadow_map_size = 1204;
int pass;
int pass_texture;

bool check_framebuffer_status();

//light
glm::vec3 lightColor = glm::vec3(1.0f, 1.0f, 1.0f);
glm::vec3 light_position = glm::vec3(0.0f, 4.0f, 2.5f);
float brightness = 1.0f; 
bool enable_hdr = false; 

//npr(nonPhotoRealistic Renddering)
bool enable_npr = false;

//shaw enable 
bool enable_shadow = false;

//enable GGX lighting 
bool enable_GGX = false;

//Ward Anisotropic
bool enable_Ward = false;

//Blinn
bool enable_Blinn = false;

//names of the mesh and texture files to load
//static const std::string mesh_name = "Amago0.obj";
static const std::string texture_name = "container.jpg";

//static const std::string mesh_name = "aal00001.ply";


glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
float cameraSpeed = 0.05f;
glm::vec3 camera_position = glm::vec3(0.0f, 0.0f, 10.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);


//control animation
int animation = 0;

const int w = 700;
const int h = 700;

//MeshData mesh_data;
float time_sec = 0.0f;
float angle = 0.0f;
bool recording = false;

glm::mat4 M_quad = glm::translate(glm::vec3(0.0f, -5.0f, - 5.5f))*glm::rotate(-45.0f, glm::vec3(1.0f, 0.0f, 0.0f))*glm::scale(glm::vec3(2.0f));

//V_cam: position and orientation of camera
//glm::mat4 V_cam = glm::lookAt(glm::vec3(0.0f, 0.0f, 10.0f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
glm::mat4 V_cam = glm::lookAt(camera_position, glm::vec3(0.0f,0.0f,0.0f), cameraUp);
//P_cam: field-of-view and near/far clip plane of camera
glm::mat4 P_cam = glm::perspective(40.0f, aspect, 0.1f, 15.0f);

//V_light: position and orientation of light
//glm::mat4 V_light = glm::lookAt(glm::vec3(0.0f, 10.0f, 0.0f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 0.0f, 1.0f));
glm::mat4 V_light = glm::lookAt(light_position, glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
//P_light: field-of-view and near/far clip plane of light
glm::mat4 P_light = glm::perspective(40.0f, aspect, 0.1f, 12.0f);



//defining the Brain structure
struct Brain
{
	std::string name;
	float object_scale;
	MeshData mesh_data;
	std::string mesh_name;
	float translate[3];

	//shader
	GLuint shader_program;
	std::string vertex_shader;
	std::string fragment_shader;

	Brain(std::string my_name, float my_object_scale, std::string my_mesh_name, std::string my_vertex_shader = "BrainData_vs.glsl", std::string my_fragment_shader = "BrainData_fs.glsl")
	{
		name = my_name; 
		object_scale = my_object_scale; 
		mesh_name = my_mesh_name; 
		translate[0] = 0.0;
		//translate[1] = 1.0;
		//translate[2] = 0.0;
		shader_program = -1;
		vertex_shader = my_vertex_shader;
		fragment_shader = my_fragment_shader;
	}
	Brain()
	{}
};
Brain bodies[NUM_BRAIN_OBJ];

void int_cerebrum()
{
	int count = 0; 

	for (int i = 1; i <= NUM_BRAIN_OBJ; i++)
	{	
		std::string name;
		
		if (i >= 100)
		{
			name = "aal00";
		}
		else if (i >= 10)
		{
			name = "aal000";
		}		
		else {
			name = "aal0000";
		}

		name += std::to_string(i);
		std::string file_type = ".ply"; 
		std::string mesh_name = name + file_type; 

		bodies[count] = Brain(name, 0.0, mesh_name);
		//std::cout << "Name " << name; 
		count++;
		if (count >= NUM_BRAIN_OBJ) return;
	}

}



//draw the scene using the specified view matrix
void draw_scene(glm::mat4& V)
{
	const int w = glutGet(GLUT_WINDOW_WIDTH);
	const int h = glutGet(GLUT_WINDOW_HEIGHT);
	const float aspect_ratio = float(w) / float(h);

	//V = glm::lookAt(camera_position, glm::vec3(0.0f, 1.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f))* glm::rotate(angle, glm::vec3(0.0f, 1.0f, 0.0f));
	//glm::mat4 P = glm::perspective(40.0f, aspect_ratio, 1.50f, 10000000.0f);
	//glm::mat4 M = glm::mat4(1.0f);
	glm::mat4 M=glm::scale(glm::vec3(0.05))*glm::rotate(angle, glm::vec3(0.0f, 1.0f, 0.0f));
	
		
	//mesh draw
	for (int i = 0; i < NUM_BRAIN_OBJ; i++)
	{
		glUseProgram(bodies[i].shader_program);
		
		pass_texture = 1; 
				
		//pass texture value 
		const int pass_texture_loc = glGetUniformLocation(bodies[i].shader_program, "pass_texture");
		if (pass_texture_loc != -1)
		{
			glUniform1i(pass_texture_loc, pass_texture);
		}

		//pass
		const int pass_loc = glGetUniformLocation(bodies[i].shader_program, "pass");
		if (pass_loc != -1)
		{
			glUniform1i(pass_loc, pass);
		}

		//draw mesh
		int VM_loc = glGetUniformLocation(bodies[i].shader_program, "VM");
		if (VM_loc != -1)
		{
			//glm::mat4 V_test = glm::lookAt(camera_position, glm::vec3(0.0f, 1.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f))* glm::rotate(angle, glm::vec3(0.0f, 1.0f, 0.0f));
			const glm::mat4 VM = V * M;
			glUniformMatrix4fv(VM_loc, 1, false, glm::value_ptr(VM));
		}		

		//camera position
		int camPos_loc = glGetUniformLocation(bodies[i].shader_program, "camPos");
		if (camPos_loc != -1)
		{
			//why matrix?
			//glUniformMatrix4fv(camPos_loc, 1, false, glm::value_ptr(camera_position));
			glUniform3f(camPos_loc, camera_position.x,camera_position.y,camera_position.z);
		}
		
		if (i < NUM_BRAIN_OBJ)
		{
						
			const int P_loc = glGetUniformLocation(bodies[i].shader_program, "P");
			if (P_loc != -1)
			{
				//glUniformMatrix4fv(P_loc, 1, false, glm::value_ptr(P_light));

				if (pass == 1)
				{
					glUniformMatrix4fv(P_loc, 1, false, glm::value_ptr(P_light));
					//std::cout << "Pass " << pass << std::endl; 
				}
				if (pass == 2)
				{
					glUniformMatrix4fv(P_loc, 1, false, glm::value_ptr(P_cam));
					//std::cout << "Pass " << pass << std::endl;
				}
				else 
				{
					glUniformMatrix4fv(P_loc, 1, false, glm::value_ptr(P_light));
				}

			}
			//Model Matrix 
			int M_loc = glGetUniformLocation(bodies[i].shader_program, "M");
			if (M_loc != -1)
			{
				glUniformMatrix4fv(M_loc, 1, false, glm::value_ptr(M));
			}

			//texture
			/*
			 int tex_loc = glGetUniformLocation(bodies[i].shader_program, "diffuse_color");
			
			//int tex_loc = glGetUniformLocation(shader_program, "texture");
			if (tex_loc != -1)
			{
				glUniform1i(tex_loc, 1); // we bound our texture to texture unit 0
			} */

			//light 
			int lightPos_loc = glGetUniformLocation(bodies[i].shader_program, "lightPos");
			if (lightPos_loc != -1)
			{
				//glUniformMatrix4fv(lightPos_loc, 1, false, glm::value_ptr(light_position));
				glUniform3f(lightPos_loc, light_position.x, light_position.y, light_position.z);
			}

			int lightColor_loc = glGetUniformLocation(bodies[i].shader_program, "lightColor");
			if (lightColor_loc != -1)
			{
				glUniform3f(lightColor_loc, lightColor.x, lightColor.y, lightColor.z);
			}

			//shadow
			GLuint enable_shadow_loc = glGetUniformLocation(bodies[i].shader_program, "enable_shadow");
			if (enable_shadow_loc != -1)
			{
				glUniform1f(enable_shadow_loc, enable_shadow);
			}

			//hdr
			GLuint brightness_loc = glGetUniformLocation(bodies[i].shader_program, "brightness");
			if (brightness_loc != -1)
			{
				glUniform1f(brightness_loc, brightness);
			}

			//enable hdr
			GLuint enable_hdr__loc = glGetUniformLocation(bodies[i].shader_program, "enable_hdr");
			if (enable_hdr__loc != -1)
			{
				glUniform1i(enable_hdr__loc, enable_hdr);
			}

			//enable npr
			GLuint enable_npr__loc = glGetUniformLocation(bodies[i].shader_program, "enable_npr");
			if (enable_npr__loc != -1)
			{
				glUniform1i(enable_npr__loc, enable_npr);
			}

			//enable GGX
			GLuint enable_GGX__loc = glGetUniformLocation(bodies[i].shader_program, "enable_GGX");
			if (enable_GGX__loc != -1)
			{
				glUniform1i(enable_GGX__loc, enable_GGX);
			}

			//enable_Ward
			GLuint enable_Ward__loc = glGetUniformLocation(bodies[i].shader_program, "enable_Ward");
			if (enable_Ward__loc != -1)
			{
				glUniform1i(enable_Ward__loc, enable_Ward);
			}

			//enable_Blinn
			GLuint enable_Blinn__loc = glGetUniformLocation(bodies[i].shader_program, "enable_Blinn");
			if (enable_Blinn__loc != -1)
			{
				glUniform1i(enable_Blinn__loc, enable_Blinn);
			}
		}
		

		glBindVertexArray(bodies[i].mesh_data.mVao);
		if (i < NUM_BRAIN_OBJ)
			glDrawElements(GL_TRIANGLES, bodies[i].mesh_data.mSubmesh[0].mNumIndices, GL_UNSIGNED_INT, 0);
		else
			glDrawElements(GL_POINTS, bodies[i].mesh_data.mSubmesh[0].mNumIndices, GL_UNSIGNED_INT, 0);
				
	} 
	//draw plane 
	//glUseProgram(shader_program);
	pass_texture = 2;

	//pass texture value 
	const int pass_texture_loc = glGetUniformLocation(shader_program, "pass_texture");
	if (pass_texture_loc != -1)
	{
		glUniform1i(pass_texture_loc, pass_texture);
	}

	int VM_loc = glGetUniformLocation(shader_program, "VM");
	if (VM_loc != -1)
	{
		const glm::mat4 VM = V * M_quad;
		glUniformMatrix4fv(VM_loc, 1, false, glm::value_ptr(VM));
	}

	glBindTexture(GL_TEXTURE_2D, texture_id);
	glBindVertexArray(quad_vao);
	glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);	
		
	//texture
	int tex_loc = glGetUniformLocation(shader_program, "texture_quard");
	if (tex_loc != -1)
	{
		glUniform1i(tex_loc, 1); // we bound our texture to texture unit 0
	}

	//light 
	int lightPos_loc = glGetUniformLocation(shader_program, "lightPos");
	if (lightPos_loc != -1)
	{
		//glUniformMatrix4fv(lightPos_loc, 1, false, glm::value_ptr(light_position));
		glUniform3f(lightPos_loc, light_position.x, light_position.y, light_position.z);
	}
	int camPos_loc = glGetUniformLocation(shader_program, "camPos");
	if (camPos_loc != -1)
	{
		//why matrix?
		//glUniformMatrix4fv(camPos_loc, 1, false, glm::value_ptr(camera_position));
		glUniform3f(camPos_loc, camera_position.x, camera_position.y, camera_position.z);
	}
	int viewPos_loc = glGetUniformLocation(shader_program, "viewPos");
	if (viewPos_loc != -1)
	{
		glUniformMatrix4fv(viewPos_loc, 1, false, glm::value_ptr(V_light));
	}

	int lightColor_loc = glGetUniformLocation(shader_program, "lightColor");
	if (lightColor_loc != -1)
	{
		glUniform3f(lightColor_loc,lightColor.x, lightColor.y, lightColor.z);
	}

	//shadow
	GLuint enable_shadow_loc = glGetUniformLocation(shader_program, "enable_shadow");
	if (enable_shadow_loc != -1)
	{
		glUniform1f(enable_shadow_loc, enable_shadow);
	}
	/*
	//hdr
	GLuint brightness_loc = glGetUniformLocation(shader_program, "brightness");
	if (brightness_loc != -1)
	{
		glUniform1f(brightness_loc, brightness);
	}
	
	//enable hdr
	GLuint enable_hdr__loc = glGetUniformLocation(shader_program, "enable_hdr");
	if (enable_hdr__loc != -1)
	{		
		glUniform1i(enable_hdr__loc, enable_hdr);
	}
	*/

}


void reload_shader()
{
	
	for (int i = 0; i < NUM_BRAIN_OBJ; i++)
	{ 
		GLuint new_shader = InitShader(bodies[i].vertex_shader.c_str(), bodies[i].fragment_shader.c_str());

		if (new_shader == -1) // loading failed
		{
			glClearColor(1.0f, 0.0f, 1.0f, 0.0f);
		}
		else
		{
			glClearColor(0.35f, 0.35f, 0.35f, 0.0f);

			if (bodies[i].shader_program != -1)
			{
				glDeleteProgram(shader_program);
			}
			bodies[i].shader_program = new_shader;

		}
	}	
}

void  reload_shader_quard()
{
	
	//GLuint new_shader = InitShader(vertex_shader.c_str(), "BrainData_quard_fs.glsl");
	GLuint new_shader = InitShader(vertex_shader.c_str(), fragment_shader.c_str());

	if (new_shader == -1) // loading failed
	{
		glClearColor(1.0f, 0.0f, 1.0f, 0.0f);
	}
	else
	{
		glClearColor(0.35f, 0.35f, 0.35f, 0.0f);

		if (shader_program != -1)
		{
			glDeleteProgram(shader_program);
		}
		shader_program = new_shader;
	}
	
	
}

//Draw the user interface using ImGui
void draw_gui()
{
   ImGui_ImplGlut_NewFrame();

   const int filename_len = 256;
   static char video_filename[filename_len] = "capture.mp4";

   //ImGui::InputText("Video filename", video_filename, filename_len);
  
   ImGui::SameLine();

   /*
   if (recording == false)
   {
      if (ImGui::Button("Start Recording"))
      {
         const int w = glutGet(GLUT_WINDOW_WIDTH);
         const int h = glutGet(GLUT_WINDOW_HEIGHT);
         recording = true;
         start_encoding(video_filename, w, h); //Uses ffmpeg
      }
      
   }
   else
   {
      if (ImGui::Button("Stop Recording"))
      {
         recording = false;
         finish_encoding(); //Uses ffmpeg
      }
   }
   */
   
   //create a slider to change the angle variables
   ImGui::SliderFloat("View angle", &angle, -3.141592f, +3.141592f);

   //create a slider to change the HDR
   ImGui::SliderFloat("Brightness", &brightness, 1.0f, 100.0f);

   //shadow 
   ImGui::Checkbox("Enable Shadow", &enable_shadow);   

   //HDR
   ImGui::Checkbox("Enable High Dynamic Range", &enable_hdr);

   //npr
   ImGui::Checkbox("Enable Nonphotorealistic Rendering", &enable_npr);

   //enable_GGX
	ImGui::Checkbox("Enable GGX Lighting", &enable_GGX);

	//enable_Ward
	ImGui::Checkbox("Enable Ward Anisotropic Lighting", &enable_Ward);

	//Blinn
	ImGui::Checkbox("Enable Blinn Lighting", &enable_Blinn);

  // Add am imgui button that reloads the shader when it is pressed
   /*
   if (ImGui::Button("Reload the shader", ImVec2(200, 25)))
   {
	   reload_shader();
	   reload_shader_quard();
   }
	*/
  // ImGui::Image((void*)texture_id, ImVec2(128,128));

   //ImGui::ShowTestWindow();
   ImGui::Render();

  
 }

void draw_pass_1() //draw from light point-of-view
{
	pass = 1;
	
	glEnable(GL_POLYGON_OFFSET_FILL);
	glPolygonOffset(10.00, 10.00); //No offset is being applied when params are 0.0, 0.0. Try changing these numbers to fix the shadow map "acne" problem
	draw_scene(V_light);
	glDisable(GL_POLYGON_OFFSET_FILL);
}

void draw_pass_2()
{
	pass = 2;

	//std::cout << "Entering draw_pass 2 " << pass << std::endl;

	glActiveTexture(GL_TEXTURE0 + 0);
	glBindTexture(GL_TEXTURE_2D, shadow_map_texture_id);

	glm::mat4 V_cam = glm::lookAt(camera_position, camera_position + cameraFront, cameraUp);

	for (int i = 0; i < NUM_BRAIN_OBJ; i++)
	{
		glUseProgram(bodies[i].shader_program);
		if (i < NUM_BRAIN_OBJ)
		{
			const int tex_loc = glGetUniformLocation(bodies[i].shader_program, "shadowmap");
			if (tex_loc != -1)
			{
				glUniform1i(tex_loc, 0); // we bound our shadowmap to texture unit 0
			}

			const int Shadow_loc = glGetUniformLocation(bodies[i].shader_program, "Shadow");
			const glm::mat4 S = glm::translate(glm::vec3(0.5f)) * glm::scale(glm::vec3(0.5f));
			if (Shadow_loc != -1)
			{
				const glm::mat4 Shadow = S * P_light*V_light*glm::inverse(V_cam); //this matrix transforms camera-space coordinates to shadow map texture coordinates
				glUniformMatrix4fv(Shadow_loc, 1, false, glm::value_ptr(Shadow));
			}

		}
	}

	//hdr 
	glActiveTexture(GL_TEXTURE0 + 1);
	glBindTexture(GL_TEXTURE_2D, colorBuffer);
	//unsigned int attachments[2] = { GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1 };
	//glDrawBuffers(2, attachments);

	draw_scene(V_cam);
}

// glut display callback function.
// This function gets called every time the scene gets redisplayed 
void display()
{
   //clear the screen
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
 
   // 1. first render to depth map
   glBindFramebuffer(GL_FRAMEBUFFER, fbo_id); // render depth to shadowmap
   glDrawBuffer(GL_NONE);
   glViewport(0, 0, shadow_map_size, shadow_map_size);
   //glViewport(0, 0, shadow_map_size-8, shadow_map_size-8);  //*hack* (Why does this work?)
   glClear(GL_DEPTH_BUFFER_BIT);
   draw_pass_1(); //Pass 1: render depth to texture from light point of view

   // 2. then render scene as normal with shadow mapping (using depth map)
   glBindFramebuffer(GL_FRAMEBUFFER, 0); // do not render to texture
   
   
   /*glDrawBuffer(GL_BACK);
   glViewport(0, 0, w, h);
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   draw_pass_2(); //Pass 2: render scene with shadowing*/


   //HDR
   glBindFramebuffer(GL_FRAMEBUFFER, hdrFBO);
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   // [...] render (lighted) scene 
   draw_pass_2();
   glBindFramebuffer(GL_FRAMEBUFFER, 0);
   

   //draw scene 
   //draw_scene(V_light);
   draw_gui();

   if (recording == true)
   {
      glFinish();

      glReadBuffer(GL_BACK);
      read_frame_to_encode(&rgb, &pixels, w, h);
      encode_frame(rgb);
   }

   glutSwapBuffers();
}

// glut idle callback.
//This function gets called between frames
void idle()
{
	glutPostRedisplay();

   const int time_ms = glutGet(GLUT_ELAPSED_TIME);
   time_sec = 0.001f*time_ms;

  // glm::mat4 M = glm::scale(glm::vec3(0.05))*glm::rotate(15.0f*time_sec, glm::vec3(0.0f, 1.0f, 0.0f));
   //glm::mat4 M = glm::scale(glm::vec3(0.05))*glm::rotate(angle, glm::vec3(0.0f, 1.0f, 0.0f));
   if (animation == 0)
   {
	   angle = 0.50f*time_sec;
   }
   /*
   else {
	  // angle = 0;
   }  */

   float timeLoc = glGetUniformLocation(shader_program, "time");
   if (timeLoc != -1)
   {
	   //Set the value of the variable at a specific location
	   glUniform1f(timeLoc, time_sec);
   }
}



// Display info about the OpenGL implementation provided by the graphics driver.
// Your version should be > 4.0 for CGT 521 
void printGlInfo()
{
   std::cout << "Vendor: "       << glGetString(GL_VENDOR)                    << std::endl;
   std::cout << "Renderer: "     << glGetString(GL_RENDERER)                  << std::endl;
   std::cout << "Version: "      << glGetString(GL_VERSION)                   << std::endl;
   std::cout << "GLSL Version: " << glGetString(GL_SHADING_LANGUAGE_VERSION)  << std::endl;
}

void initOpenGl()
{
   //Initialize glew so that new OpenGL function names can be used
   glewInit();

   //Lab 1.3.... Debugging OpenGL
   //Register the debug callback function
 //  RegisterCallback();

   glEnable(GL_DEPTH_TEST);

   reload_shader();
   reload_shader_quard();

   //load brain mesh
   for (int i = 0; i < NUM_BRAIN_OBJ; i++) 
   {
	   //Load a mesh and a texture
	   bodies[i].mesh_data = LoadMesh(bodies[i].mesh_name);
   }
  
   float tex_coord_attrib[] = {
	1.0f, 1.0f, // top right
	1.0f, 0.0f, // bottom right
	0.0f, 0.0f, // bottom left
	0.0f, 1.0f  // top left 
   };
   //mesh for quadrilateral
   quad_vbo = -1;

   glGenVertexArrays(1, &quad_vao);
   glBindVertexArray(quad_vao);

   //draw quard
  // float vertices[] = { 1.0f, 1.0f, 0.0f, 1.0f, -1.0f, 0.0f, -1.0f, 1.0f, 0.0f, -1.0f, -1.0f, 0.0f };
	float vertices[] = { 
		               // positions          // normals    // texture coords
						6.0f, 6.0f, 0.0f,   0.0,1.0,0.0,    1.0f, 1.0f,
						6.0f, -6.0f, 0.0f,  0.0,1.0,0.0,    1.0f, 0.0f,
					   -6.0f, 6.0f, 0.0f,   0.0,1.0,0.0,    0.0f, 0.0f,
					   -6.0f, -6.0f, 0.0f,  0.0,1.0,0.0,    0.0f, 1.0f
					};

   //create vertex buffers for vertex coords
   glGenBuffers(1, &quad_vbo);
   glBindBuffer(GL_ARRAY_BUFFER, quad_vbo);
   glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
  // glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
   glUseProgram(shader_program);
   int pos_loc = glGetAttribLocation(shader_program, "pos_attrib");
   if (pos_loc >= 0)
   {
	   glEnableVertexAttribArray(pos_loc);
	   glVertexAttribPointer(pos_loc, 3, GL_FLOAT, false, 8 * sizeof(float), 0);
   }

   int normal_loc = glGetAttribLocation(shader_program, "normal_attrib");
   if (normal_loc >= 0)
   {
	   glEnableVertexAttribArray(normal_loc);
	   glVertexAttribPointer(normal_loc, 3, GL_FLOAT, false, 8 * sizeof(float), (void*)(3 * sizeof(float)));
   }

   int tex_coord_attrib_loc = glGetAttribLocation(shader_program, "tex_coord_attrib");
   if (tex_coord_attrib_loc >= 0)
   {
	   glEnableVertexAttribArray(tex_coord_attrib_loc);
	   glVertexAttribPointer(tex_coord_attrib_loc, 2, GL_FLOAT, false, 8 * sizeof(float), (void*)(6 * sizeof(float)));
   }
   //load texture
  // texture_id = LoadTexture(texture_name.c_str()); //Helper function: Uses FreeImage library
   
   //texture
   //unsigned int texture;
   glGenTextures(1, &texture_id);
   glBindTexture(GL_TEXTURE_2D, texture_id);
   // set the texture wrapping/filtering options (on the currently bound texture object)
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

   // load and generate the texture
   int width, height, nrChannels;
   unsigned char *data = stbi_load("container.jpg", &width, &height, &nrChannels, 0);
   if (data)
   {
	   glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
	   glGenerateMipmap(GL_TEXTURE_2D);
   }
   else
   {
	   std::cout << "Failed to load texture" << std::endl;
   }
   stbi_image_free(data);

   
  // glGenVertexArrays(1, &vao);
   /*glBindTexture(GL_TEXTURE_2D, texture_id);
   glBindVertexArray(quad_vao);
   glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);	*/
   

   //shadow map
	//create shadow map texture to hold depth values (note: not a renderbuffer)
   glGenTextures(1, &shadow_map_texture_id);
   glBindTexture(GL_TEXTURE_2D, shadow_map_texture_id);
   glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT32, shadow_map_size, shadow_map_size, 0, GL_DEPTH_COMPONENT, GL_FLOAT, 0);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   // Aliasin: Percentage Closer Filtering(PCF)
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);

   glBindTexture(GL_TEXTURE_2D, 0);

   //create the framebuffer object: only has a depth attachment
   glGenFramebuffers(1, &fbo_id);
   glBindFramebuffer(GL_FRAMEBUFFER, fbo_id);
   glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, shadow_map_texture_id, 0);
   check_framebuffer_status();
   glBindFramebuffer(GL_FRAMEBUFFER, 0);

   //HDR (High Dynamic Range)
   // create floating point color buffer
   //unsigned int colorBuffer;
   glGenTextures(1, &colorBuffer);
   glBindTexture(GL_TEXTURE_2D, colorBuffer);
   glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA16F, w, h, 0, GL_RGBA, GL_FLOAT, NULL);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   // create depth buffer (renderbuffer)
   unsigned int rboDepth;
   glGenRenderbuffers(1, &rboDepth);
   glBindRenderbuffer(GL_RENDERBUFFER, rboDepth);
   glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT, w, h);
   // attach buffers
   glBindFramebuffer(GL_FRAMEBUFFER, hdrFBO);
   glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, colorBuffer, 0);
   glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, rboDepth);
   check_framebuffer_status();
   glBindFramebuffer(GL_FRAMEBUFFER, 0);
   	  
   
   
   
}

// glut callbacks need to send keyboard and mouse events to imgui
void keyboard(unsigned char key, int x, int y)
{
   ImGui_ImplGlut_KeyCallback(key);
   std::cout << "key : " << key << ", x: " << x << ", y: " << y << std::endl;

   switch(key)
   {
      case 'r':
      case 'R':
         reload_shader();     
		 reload_shader_quard();
      break;
   }

   if (key == '+')
   {
	   // keyPressed = true;
	   camera_position += cameraSpeed * cameraFront;
   }
  
   if (key == '-')
   {
	   camera_position -= cameraSpeed * cameraFront;
   }
 
	//control animation 
   if (key == ' ')
   {
	   animation = 1 - animation;
   }

}

void keyboard_up(unsigned char key, int x, int y)
{
   ImGui_ImplGlut_KeyUpCallback(key);
}

void special_up(int key, int x, int y)
{
   ImGui_ImplGlut_SpecialUpCallback(key);

}

void passive(int x, int y)
{
   ImGui_ImplGlut_PassiveMouseMotionCallback(x,y);
}

void special(int key, int x, int y)
{
   ImGui_ImplGlut_SpecialCallback(key);
}

void motion(int x, int y)
{
   ImGui_ImplGlut_MouseMotionCallback(x, y);
}

void mouse(int button, int state, int x, int y)
{
   ImGui_ImplGlut_MouseButtonCallback(button, state);
}

//control windoe distortion 
void reshape(int w, int h)
{
	glViewport(0, 0, w, h);
	aspect = (float)w / h;
	//P_cam = glm::perspective(40.0f, aspect, 0.1f, 15.0f);
	//P_light = glm::perspective(40.0f, aspect, 0.1f, 12.0f);

}

int main (int argc, char **argv)
{
	//Lab 1.3.... Debugging OpenGL
	#if _DEBUG
		glutInitContextFlags(GLUT_DEBUG);
	#endif
		glutInitContextVersion(4, 3);

   //Configure initial window state using freeglut
   glutInit(&argc, argv); 
   glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
   glutInitWindowPosition (5, 5);
   glutInitWindowSize (1350, 720); //1280

   int win = glutCreateWindow ("Brain Data Visualize");

   printGlInfo();
   int_cerebrum();
 
   //Register callback functions with glut. 
   glutDisplayFunc(display); 
   glutKeyboardFunc(keyboard);
   glutSpecialFunc(special);
   glutKeyboardUpFunc(keyboard_up);
   glutSpecialUpFunc(special_up);
   glutMouseFunc(mouse);
   glutMotionFunc(motion);
   glutPassiveMotionFunc(motion);

   glutIdleFunc(idle);

   //tp control windows distortion 
   glutReshapeFunc(reshape);

   initOpenGl();
   ImGui_ImplGlut_Init(); // initialize the imgui system

   //Enter the glut event loop.
   glutMainLoop();
   glutDestroyWindow(win);
   return 0;		
}

bool check_framebuffer_status()
{
	GLenum status;
	status = (GLenum)glCheckFramebufferStatus(GL_FRAMEBUFFER);
	switch (status) {
	case GL_FRAMEBUFFER_COMPLETE:
		return true;
	case GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT:
		printf("Framebuffer incomplete, incomplete attachment\n");
		return false;
	case GL_FRAMEBUFFER_UNSUPPORTED:
		printf("Unsupported framebuffer format\n");
		return false;
	case GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT:
		printf("Framebuffer incomplete, missing attachment\n");
		return false;
	case GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER:
		printf("Framebuffer incomplete, missing draw buffer\n");
		return false;
	case GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER:
		printf("Framebuffer incomplete, missing read buffer\n");
		return false;
	}
	return false;
}
